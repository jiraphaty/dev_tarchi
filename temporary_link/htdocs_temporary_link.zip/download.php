<?php
include "class_temporary.php";
if(isset($_GET['key'])){
	$temporary = new Temporary();
	$now = $temporary->get_time_now();
	$now = $temporary->dateToTime($now);
	$row = $temporary->decode_base64($_GET['key']);
	$key = $temporary->get_key_db($row);
	if($key){
		if($key['expire'] < $now){
			echo "<h3>Link was Expired.</h3>";
		}else{
			if($key['limit_']==0){
				$temporary->setLink($key['link']);
				$temporary->get_download();
			}else{
				if($key['count_'] < $key['limit_']){
					$data['key'] = $key['key_'];
					$data['count'] = $key['count_']+1;
					if($temporary->decrease_count($data)){
						$temporary->setLink($key['link']);
						$temporary->get_download();
					}
				}else{
					$temporary->del_key_db($key['key_']);
					echo "<h3>Link was full.</h3>";
				}
			}
		}
	}else{
		echo "<h3>Link was not found.</h3>";
	}
}
?>