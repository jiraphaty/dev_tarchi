<?php

Class Temporary{
	
	private $pdo;
	private $limit = 0;
	private $link_ = "";
	private $time = 1;
	private $type = 'days';
	
	public function __construct(){
		date_default_timezone_set("Asia/Bangkok");
		$host = "localhost";
		$user = "root";
		$pass = "";
		$dbname = "temporary_link";
		try{
			$this->pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
			$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}catch(PDOException $e){
			echo "ไม่สามารถเชื่อมดาต้าเบสได้ ";
			exit;
		}
	}
	
	public function setLink($link){
		$this->link_ = $link;
	}
	
	public function setLimit($limit){
		$this->limit = $limit;
	}
	
	public function setTime($time){
		$this->time = $time;
	}
	
	public function setTypes($type){
		$this->type = $type;
	}
	
	public function create_key(){
		return md5(microtime().rand());
	}
	
	public function create_key_expire(){
		$key = $this->create_key();
		$time = $this->get_time_expire($this->time, $this->type);
		$time = $this->dateToTime($time);
		$data['key'] = $key;
		$data['expire'] = $time;
		$data['link'] = $this->link_;
		$data['limit'] = $this->limit;
		$this->reset_auto_increment();
		$this->insert_key_db($data);
		
		return $this->encode_base64($key);
	}
	
	public function encode_base64($str){
		return  base64_encode($str);
	}
	
	public function decode_base64($base){
		return base64_decode($base);
	}
	
	public function get_time_now(){
		return date('Y-m-d H:i:s', strtotime('now'));
	}
	
	public function get_time_expire($time, $type = 'days'){
		return date('Y-m-d H:i:s', strtotime('now' . "+" . $time . " $type"));
	}
	
	public function timeToDate($timestamp){ 
		return date("Y-m-d H:i:s", $timestamp);
	}
	
	public function dateToTime($datetime){
		$exp = explode(" ",$datetime);
		$t = explode(":",$exp[1]);
		$d = explode("-",$exp[0]);
		return mktime($t[0], $t[1], $t[2], $d[1], $d[2], $d[0]);
	}
	
	public function get_key_db($key){
		$get = $this->pdo->prepare("SELECT * FROM temporary WHERE key_ = ?");
		$get->bindparam(1, $key);
		$get->execute();
		
		$row = $get->fetch();
		
		return $row;
	}
	
	public function insert_key_db($data){
		$in = $this->pdo->prepare("INSERT INTO temporary VALUES (NULL, ?, ?, ?, ?, 0)");
		$in->bindparam(1, $data['key']);
		$in->bindparam(2, $data['expire']);
		$in->bindparam(3, $data['link']);
		$in->bindparam(4, $data['limit']);
		
		return $in->execute();
	}
	
	public function decrease_count($data){
		$up = $this->pdo->prepare("UPDATE temporary SET count_ = ? WHERE key_ = ?");
		$up->bindparam(1, $data['count']);
		$up->bindparam(2, $data['key']);
		
		return $up->execute();
	}
	
	public function del_key_db($key){
		$del = $this->pdo->prepare("DELETE FROM temporary WHERE key_ = ?");
		$del->bindparam(1, $key);
		
		return $del->execute();
	}
	
	public function reset_auto_increment(){
		$reset = $this->pdo->prepare("ALTER TABLE temporary AUTO_INCREMENT = 1");
		return $reset->execute();
	}
	
	public function get_header(){
		return get_headers($this->link_, true);
	}
	
	public function get_download(){
		$file = fopen($this->link_, 'r');
		header("Content-Type:text/plain");
		header("Content-Disposition: attachment; filename=".basename($this->link_));
		fpassthru($file);
	}
	
}
?>