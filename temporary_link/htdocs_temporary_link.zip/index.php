<!DOCTYPE html>
<html lang="en">
<head>
	<title>Temporary Link</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="text-center">
			<h3>ลิ้งค์ดาวน์โหลดชั่วคราว</h3>
		</div>
		<center>
		<div style="width: 550px;box-shadow: 0px 3px 17px 5px rgba(0,0,0,0.46);padding: 20px;">
			<form method="GET">
				<div class="form-group">
					<label for="">ลิ้งค์ไฟล์ที่ต้องการสร้าง:</label>
					<input type="text" class="form-control" placeholder="http://www.temporary.com/file.mp4" name="link" value="<?php if(isset($_GET['link'])) echo $_GET['link']; ?>" required>
				</div>
				<div class="form-group">
					<label for="">จำนวนครั้ง: ( 0 = ไม่จำกัด )</label>
					<input type="number" class="form-control" min="0" name="limit" value="<?php if(isset($_GET['limit'])) echo $_GET['limit']; else echo "0";?>" required>
				</div>
				<div class="form-group">
					<label for="">เวลาหมดอายุ: </label>
					<input type="number" class="form-control" min="1" name="time" value="<?php if(isset($_GET['time'])) echo $_GET['time']; else echo "1";?>" required>
				</div>
				<div class="form-group">
					<select class="form-control" name="type" required>
						<option value="seconds">วินาที</option>
						<option value="minutes">นาที</option>
						<option value="hours">ชั่วโมง</option>
						<option value="days" selected>วัน</option>
						<option value="months">เดือน</option>
						<option value="years">ปี</option>
					</select>
				</div>
				<button type="submit" class="btn btn-default" name="create" value="ok">สร้าง</button>
			</form>
			<br>
			<?php 
				if(isset($_GET['create'])):
					include "class_temporary.php";
					$link = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://" . $_SERVER["SERVER_NAME"] . '/' . trim(dirname($_SERVER["PHP_SELF"]),'\\/').'/';
					define('base_url', $link.'download?key=');
					$temporary = new Temporary();
					$temporary->setLink($_GET['link']);
					$temporary->setLimit($_GET['limit']);
					$temporary->setTime($_GET['time']);
					$temporary->setTypes($_GET['type']);
					$key = $temporary->create_key_expire();
			?>
			<textarea class="form-control" rows="5" style="resize: vertical;" id="created_link"><?=base_url.$key?></textarea>
			<br>
			<form method="GET">
				<a href="<?=base_url.$key?>" target="_blank" class="btn btn-warning">ดาวน์โหลด</a>
				<button type="button" class="btn btn-info" onclick="copyToClib()">คัดลอก</button>
				<button type="submit" class="btn btn-danger" name="clear" value="ok">เคลียร์</button>
			</form>
			<script>
				function copyToClib(){
					var copyText = document.getElementById("created_link");
					copyText.select();
					document.execCommand("copy");
				}
			</script>
			<?php
				if(isset($_GET['clear'])):
					header('Location: '.$_SERVER["PHP_SELF"], true, 303);
				endif;
			?>
			<?php endif; ?>
		</div>
		</center>
	</div>
</body>
</html>